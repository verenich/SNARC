console.log("====== SNARC Background is in action !!! =======");

/*  Attaching the pusher API to the document, injecting the script
int the content script and even whitlisting did not work .. this is
the solution */

var pusherScript = document.createElement('script');

pusherScript.src = chrome.extension.getURL("lib/pusher.js");
pusherScript.onload = function(){ this.parentNode.removeChild(this);};
(document.head || document.documentElement).appendChild(pusherScript);

//initializing the default options 
var defaults = { intents: true, scroll: true, https: true };

window.snarc = {
    checkForValidUrl: function(url)
    {
        var badWords = ["chrome://"];
        for (var b = 0; b < badWords.length; b++)
            if (url.indexOf(badWords[b]) > -1) return false;
        if (!window.snarc.settings.allowOnHttps) return url.indexOf("https") === -1;
        return true;
    },

    startPusher: function()
    {
        console.log("Starting Listenting to SNARC Stream !!");

        var pusher, channel, port;
        chrome.tabs.getSelected(null, function(tab) {
            //initialize pusher with the API key
            pusher = new Pusher('897f81550cd6da4f4df3');
            //create a unique Channel ID for each extension instance
            var channelName = tab.id + tab.url.replace(/[^\w\s]/gi, '');
            channel = pusher.subscribe(channelName);

            channel.bind('subscribe', function(data){
                port.postMessage({message: data});
            });

            port = chrome.tabs.connect(tab.id);
            port.postMessage({message: "Hello from Background.js !! "});

            port.onMessage.addListener(function getResp(response) {
                console.log(response);
            });
        });
    },

    updateSettings: function()
    {

        chrome.storage.sync.get("data", function(options)
        {
            if (options && !jQuery.isEmptyObject(options))
            {
                var settings = defaults;
                $.each(options.data.data, function(key, value)
                {
                    if (value.id == "intents") settings.intents = value.value;
                    else if (value.id == "scroll") settings.scroll = value.value;
                    else if (value.id == "https") settings.https = value.value;
                });
                window.snarc.settings = settings;
            }
            else console.log("First Run !! Settings are Default ");
            window.snarc.sendRequest();
        });
    },
    sendRequest: function()
    {
        chrome.tabs.getSelected(null, function(tab)
        {
            if (window.snarc.checkForValidUrl(tab.url))
            {
                chrome.tabs.sendMessage(tab.id,
                {
                    message: "buildSidebar",
                    url : tab.url ,
                    channelName: tab.id + tab.url.replace(/[^\w\s]/gi, '')
                }, function(response)
                {
                    console.log(response.message);
                });
            }
            else console.log("ERROR HAPPENED ON: " + tab.url);
        });
    },
    settings: defaults
};


chrome.browserAction.onClicked.addListener(function(tab)
{
    window.snarc.startPusher();
    window.snarc.updateSettings();
});