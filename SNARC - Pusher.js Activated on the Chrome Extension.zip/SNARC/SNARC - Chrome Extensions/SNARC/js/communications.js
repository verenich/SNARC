console.log("====== STARTED LISTENING TO COMMUNICATIONS ====== ")

if (!window.snarc) {
	window.snarc = {};
}

window.snarc.communication =  {};

chrome.runtime.onConnect.addListener(function(port) {
	port.onMessage.addListener(function(msg) {
		port.postMessage({message: msg.message + " -> Received Successfull"});
		window.snarc.updateStream(msg.message);
	});
});

chrome.runtime.onMessage.addListener(
	function(request, sender, sendResponse) {
		if (request.message == "buildSidebar") {
			window.snarc.buildSidebar(request.url, request.channelName);
			sendResponse({message: " --> Sidebar Created on the Front-End !!"});
		}
	});


