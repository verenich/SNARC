console.log("====== SNARC is in action !!! =======");

if (!window.snarc)
{
    window.snarc = {};
}

jQuery.extend(window.snarc,
{
    updateStream: function(data) {
       console.log(data);
    },

    buildSidebar: function(url,channelName)
    {
        console.log(" --> Building SNARC Sidebar .... ");
        console.log(url);  console.log(channelName);
        var side_bar = $('<article class="snarc-sidebar"></article>').appendTo($('body'));
        var loading_spinner = '<div class="loading"><i class="icon-signal"></i>Loading Social Sidebar' +
                              '<img class"spinner" src="' + chrome.extension.getURL('icons/ajax-loader.gif') +
                              '"/></div>';
        var social_list = $('<ul id = "realted_social" class="social_stream"></ul>').appendTo(side_bar);
        //Append the sidebar with the loader and apply niceScroll
        $(".social_stream").niceScroll({cursorcolor:"#000",railoffset:{top:30}});
        $(loading_spinner).appendTo(side_bar);
        //call the SNARC AJAX Service
        window.snarc.AJAXCall(url,channelName);
        return true;
    },

    AJAXCall: function(url,channelName)
    {
        jQuery.ajax(
        {
            url: 'http://ahmadassaf.com/SNARC/SNARC-AJAX.php',
            type: 'POST',
            dataType: 'json',
            data: {
                url: url, channelName:channelName
            },
            success: function(data, textStatus, xhr)
            {
                console.log(data);
            },
            error: function(xhr, textStatus, errorThrown)
            {
                console.log(xhr);
                $('.snarc-sidebar .loading').text('Error Loading Social Bar').css('color', '#d73532');
            }
        });
    }
});