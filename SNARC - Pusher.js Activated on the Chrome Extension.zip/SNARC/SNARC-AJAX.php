<?php 

	header('Content-type: application/json');
	date_default_timezone_set('UTC');

	$pusher_app_id      = '44071';
	$pusher_app_key     = '897f81550cd6da4f4df3';
	$pusher_app_secret  = '0d3250dbb5b872fb9b6e';	

	require_once('DocumentBuilder/semanticDocumentBuilder.php');
	require_once('Utilities/util.php');
	require_once('Utilities/simpleCache.php');
	require_once ('APIs/pusher.php');

	$pusher = new Pusher( $pusher_app_key, $pusher_app_secret, $pusher_app_id );
	$pusher->trigger( $_POST['channelName'], 'subscribe', 'You have been Connected Successfully to SNARC Service' );

	$semanticDocumentBuilder = new semanticDocumentBuilder();
	$result =  $semanticDocumentBuilder->build($_POST['url']);
	$pusher->trigger( $_POST['channelName'], 'documentReady', $result );

	echo json_encode($result);
	die();

?>