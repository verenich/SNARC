<?php	

require_once ('social-search.php');

class socialParser {

	private $youtube_lists;
	private $arguments;
	private $result;

	public function socialParser($args)
	{
		$this->result = array();
		$this->youtube_lists = array(
			"data-analysis"   => "PLAO-bgRLoAHH8IkmuOYcfTCKSlozG2-os",
			"programming"     => "PLAO-bgRLoAHGlXatHfvRyEkl3tbccajdn",
			"semantic-web"    => "PLAO-bgRLoAHGXheeJ5jJwgrDJcXJ5JkFQ",
			"javascript"      => "PLAO-bgRLoAHGpHe1hAX3UOWCdWpOJodPo",
			"php"             => "PLAO-bgRLoAHFpnmDwViefaCuBpIgzcoGr",
			"web-development" => "PLAO-bgRLoAHG1KCUUvjYflkxT0ZniqGAg",
			"python"          => "PLAO-bgRLoAHFDyY6rUJOFL-umFeipQEvy",
			"mobile"          => "PLAO-bgRLoAHGtOv1SZRFshL0Ri19QXvh3",
			"databases"       => "PLAO-bgRLoAHGdCIUwdT1o1bu9AWdqnI79",
			'java'            => "PLAO-bgRLoAHE-Di1j0XFcK3aYB1vp8mXa",
			"miscellaneous"   => "PL0DEEDD3ECC96B4A5"
			);

		$this->arguments = array(
			"google_plus"             => $args["keywords"],			
			"youtube_playlist"        => $args["youtube_playlists"] ? $this->replace_youtube_ids($args["youtube_playlists"]) : "",
			"youtube_semantic_search" => $args["keywords"],
			"youtube_search"          => $args["keywords"],			
			"twitter_list"            => $args["twitter_lists"],
			"twitter_search"          => $args["twitter_search"],			
			"slideshare"              => $args["keywords"],
			"stackoverflow"           => $args["keywords"],
			"vimeo"                   => $args["keywords"],
			"zemanta"                 => $args["zemanta"]);		
	}

	function build() {
		date_default_timezone_set('UTC');
		$social_query = new socialSearch();	
		$social_results = $social_query->build($this->arguments);
		if ($social_results) {		
			foreach ($social_results as $key=>$value) {	
				$this->result[] = call_user_func_array(array($this, $key), array($value));
			}		
		}
		return $this->result;
	}

	function youtube_data($result) {
		foreach ($result as $video) {	
			$args = array(
				"service" => "youtube",
				"type"    => "video",
				"time"    => utility::timeAgo(strtotime($video->snippet->publishedAt)),
				"title"   => $video->snippet->title,
				"author"  => $video->snippet->channelTitle,
				"embed"   => $video->id->videoId
				);
		}	
		$this->result[] = $args; 
	}

	function youtube($result) {
		foreach ($result as $video) {	
			$args = array(
				"service" => "youtube",
				"type"    => "video",
				"time"    => isset($video->published->_t) ? utility::timeAgo(strtotime($video->published->_t)) : utility::timeAgo(strtotime($video->published)),
				"title"   => isset($video->title->_t) ? $video->title->_t : $video->title,
				"link"    => $video->link[0]->href,
				"author"  => isset($video->author->name->_t) ? $video->author->name->_t  : $video->group->credit->display,
				"embed"   => utility::parse_youtube_url($video->link[0]->href)
				);
			$this->result[] = $args; 
		}
	}

	function google_plus($result) {
		$author = $thumbnail =  $image = "";
		foreach ($result[0]->items as $entry) {
			if ($entry->object->objectType != "image") {
				$time = utility::timeAgo(strtotime($entry->published));
				$item      = $entry->object;

				$thumbnail = $entry->actor->image->url;
				$author    = $entry->actor->displayName;
				$url       = $entry->url;
				$profile   = $entry->actor->url;
				if (isset($entry->title)) $title = $entry->title;

				if (isset($item->attachments)) {				
					$title                                                  = $item->attachments[0]->displayName;
					if (isset($item->attachments[0]->fullImage)) $image     = $item->attachments[0]->fullImage->url;
				} 
				if (!$title) $title = $item->content;
				$args = array(
					"service"   => "google",
					"type"      => "micropost",
					"time"      => $time,
					"title"     => substr($title, 0, 60),
					"link"      => $url,
					"profile"	=> $profile,
					"author"    => $author,
					"thumbnail" => $thumbnail
					);
				$this->result[] = $args; 
			}
		}
	}

	function zemanta($result) {
		if ($result[0]->articles) {
			foreach ($result[0]->articles as $entry) {
				$args = array(
					"service"   => "zemanta",
					"type"      => "post",
					"time"      => utility::timeAgo(strtotime($entry->published_datetime)),
					"title"     => $entry->title,
					"link"      => $entry->url,
					"content"   => $entry->text_preview
					);
				$this->result[] = $args; 
			}
		}
	}

	function twitter($result) {
		foreach ($result[0] as $tweet) {
			if ($tweet && isset($tweet->id)) {
				$args = array(
					"service"   => "twitter",
					"type"      => "micropost",
					"time"      => utility::timeAgo(strtotime($tweet->created_at)),
					"title"     => utility::makeUrls($tweet->text),
					"link"      => $tweet->id_str,
					"author"    => isset($tweet->user->screen_name) ? $tweet->user->screen_name : $tweet->user->name,
					"thumbnail" => $tweet->user->profile_image_url,
					"program" 	=> $tweet->source
					);
				$this->result[] = $args; 
			}
		}	
	}

	function stackoverflow($result) {
		foreach ($result as $question) {
			$args = array(
				"service"   => "stackoverflow",
				"type"      => "question",
				"time"      => utility::timeAgo(Date($question->creation_date)),
				"title"     => $question->title,
				"link"      => $question->question_id,
				);
			$this->result[] = $args; 
		}
	}

	function vimeo($result) {
		$oembed_endpoint = 'http://vimeo.com/api/oembed.xml';
		foreach ($result[0] as $video) {
			$oembed_url = $oembed_endpoint . '?url=' . rawurlencode($video->urls->url[0]->_content);
			$oembed = simplexml_load_string(utility::getCURLResult($oembed_url));
			$embed_code = html_entity_decode($oembed->html);
			$args = array(
				"service"   => "vimeo",
				"type"      => "video",
				"title"     => $video->title,
				"time"      => utility::timeAgo(strtotime($video->modified_date)),
				"link"      => $video->urls->url[0]->_content,
				"author"    => $video->owner->display_name,
				"thumbnail" => $video->thumbnails->thumbnail[1],
				"like"      => $video->number_of_likes,
				"embed"     => $embed_code
				);
			$this->result[] = $args; 
		}
	}

	function slideshare($result) {	
		foreach ($result[0]->Slideshow as $slide) {
			$args = array(
				"service"   => "slideshare",
				"type"      => "slide",
				"time"      => utility::timeAgo(strtotime($slide->Updated)),
				"title"     => $slide->Title,
				"link"      => isset($slide->DownloadUrl) ? $slide->DownloadUrl : "",
				"author"    => $slide->Username,
				"thumbnail" => $slide->ThumbnailURL,
				"embed"     => $slide->Embed
				);
			$this->result[] = $args;
		}
	}

	function replace_youtube_ids($categories) {
		$youtube_ids = array();
		foreach ($categories as $cat) {
			$youtube_ids[] = $this->youtube_lists[$cat];
		}
		return $youtube_ids;
	}
}

?>