<?php

class youTubeMapper {

	public function __construct()
	{
		$this->json   = file_get_contents('alchemy_youtube_mapper.json', true);
		$this->result = array();	
	}

	function map($alchemy_category) {
		$result = array();
		$mappings = json_decode($this->json)->data;
		foreach ($mappings as $key=>$value ) {
			if (isset($value->alchemyCode) && $value->alchemyCode == $alchemy_category) {
				$result = $value;
			}
		}
		return $result;
	}
}

?>