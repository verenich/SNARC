<?php
require_once ('util.php');
require_once ('google/Google_Client.php');
require_once ('google/Google_YouTubeService.php');
require_once ('twitter-oauth.php');

class socialSearch {

  private $result;
  private $vimeo_key;
  private $vimeo_secret;
  private $google_key;
  private $client;
  private $cache;
  private $twitter;
  private $zemanta_key;

  public function __construct()
  {
    $this->result       = array();
    $this->vimeo_key    = "8d21ef0f9c3693e2dcad5a4e4847554b9cc4d288";
    $this->vimeo_secret = "58642e824aed3b2f3da67db7c79c48cb2b0d2bc3";
    $this->google_key   = "AIzaSyCa58KRY6XmjxmMsiSBMXLKxsSBC3_Yf40";
    $this->zemanta_key  = "xdjapswuumufqgjob52swtln";
    $this->client       = new Google_Client();
    $this->cache        = new SimpleCache();
    $this->twitter      = Codebird::getInstance();

    Codebird::setConsumerKey('ECX9Nfjs12U2CQHGq0dHqw', 'oXju7ytKu5KW1HDW3bOWvjAIIGuO61Oi7BFdVFNais'); 
    $this->twitter->setToken('88829451-8sbKOhSzzQ3Yf2qSA281kxNeiV9pD14XdILblzKfI', 'jN99xiPsYltk9G3wuBSEp3vVSuZOdDOUSa3Orm8A');
    $this->client->setDeveloperKey($this->google_key);
  }

  function build($arg) {
    date_default_timezone_set('UTC');
    foreach ($arg as $key => $value) {
      if (is_array($value)) {
        foreach ($value as $keyword) {
         call_user_func_array(array($this, $key), (array)$keyword);
       }
     } else  if ($value) call_user_func_array(array($this, $key), array($value));     
   }
   return $this->result;
 }


 function youtube_playlist($channel) {
  if($youtube_playlist_decoded = $this->cache->get_cache($channel)){
    $youtube_playlist = json_decode($youtube_playlist_decoded);
  } 
  else { 
    $youtube_playlist_query = "select * from xml where url='https://gdata.youtube.com/feeds/api/playlists/$channel?v=2&max-results=5&key=". $this->google_key ."'";
    $youtube_playlist = utility::getYQLResult($youtube_playlist_query);
    $this->cache->set_cache($channel, json_encode($youtube_playlist));
  }
  if (isset($youtube_playlist->feed)) {
    foreach ($youtube_playlist->feed->entry as $video) {
      $this->result["youtube"][] =  $video;
    }
  }
}

function youtube_semantic_search($keyword) {
  if($searchResponse_semantic_decoded = $this->cache->get_cache('semantic_youtube-'.$keyword)){
    $searchResponse_semantic = json_decode($searchResponse_semantic_decoded);
  } 
  else { 
    $youtube = new Google_YoutubeService($this->client);
    $concepts = $this->getFreebaseConcept($keyword);
    $concept_depth = 3; $counter = 0;
    while ($counter < $concept_depth && !isset($searchResponse_semantic) && $concepts ) {
      try {
        $searchResponse_semantic = $youtube->search->listSearch('snippet', array(
          'topicId'    => is_array($concepts->result) ? $concepts->result[$counter++]->mid : $concepts->result->mid  ,
          'order'      => 'viewCount',
          'maxResults' => 5
          ));
        $this->cache->set_cache('semantic_youtube-'.$keyword, json_encode($searchResponse_semantic));

        if (isset($searchResponse_semantic)) {  
          foreach ($searchResponse_semantic->items as $video) {
            $this->result["youtube_data"][] =  $video;
          }
        }
      } catch (Google_ServiceException $exception) {}
    }
  }
}

function stackoverflow($keyword) {
  if($stackoverflow_search_decoded = $this->cache->get_cache('stackoverflow-'.$keyword)){
    $stackoverflow_search = json_decode($stackoverflow_search_decoded);
  } else {
    $url = "select * from json where url='http://api.stackoverflow.com/1.1/search?intitle=". urlencode($keyword) . "&pagesize=10&sort=votes'";
    $stackoverflow_search = utility::getYQLResult($url);
    $this->cache->set_cache('stackoverflow-'.$keyword, json_encode($stackoverflow_search));
  }
  if (isset($stackoverflow_search->json->questions)) {
    foreach($stackoverflow_search->json->questions as $entry) {
     $this->result["stackoverflow"][] =  $entry;
   }     
 }  
}

function zemanta($zemanta) {
  if($related_posts_decoded = $this->cache->get_cache('zemanta-'.substr($zemanta->title, 0,15))){
    $related_posts = json_decode($related_posts_decoded);
  } else {
    $url  = 'http://api.zemanta.com/services/rest/0.0/'; $data = "";
    $args = array(
      'method'           => "zemanta.suggest",
      'api_key'          => $this->zemanta_key,
      'text'             => $zemanta->text,
      'format'           => 'json',
      'return_images'    => 0,
      'return_keywords'  => 0,
      'return_rdf_links' => 0,
      'text_title'       => $zemanta->title);

    foreach($args as $key=>$value)
      { $data .= ($data != "")?"&":"";
    $data .= urlencode($key)."=".urlencode($value);}

    $related_posts = utility::getCURLPostResult($url,$data);
    $this->cache->set_cache('zemanta-'.substr($zemanta->title, 0,15), json_encode($related_posts));
  }
  if (isset($related_posts)) $this->result["zemanta"][] =  $related_posts;
}

function youtube_search($keyword) {
  if($youtube_search_decoded = $this->cache->get_cache('youtube_search-'.$keyword)){
    $youtube_search = json_decode($youtube_search_decoded);
  } else {
    $url = "select * from json where url='http://gdata.youtube.com/feeds/api/videos?q=$keyword&alt=json&lr=en&strict=true&category=education&max-results=5&key=". $this->google_key ."'";
    $youtube_search = utility::getYQLResult($url);
    $this->cache->set_cache('youtube_search-'.$keyword, json_encode($youtube_search));
  }
  if (isset($youtube_search->json->feed->entry)) {
    foreach ($youtube_search->json->feed->entry as $video) {
      $this->result["youtube"][] =  $video;
    }
  }    
}

function getFreebaseConcept($keyword) {
  $url = "select * from json where url=' https://www.googleapis.com/freebase/v1/search?query=$keyword&filter=". urlencode("(any domain:computer/)"). "'";
  $freebase_result = utility::getYQLResult($url);
  if (isset($freebase_result->json->result)) 
    return $freebase_result->json;
}

function google_plus($keyword) {
  if($searchResponse_decoded = $this->cache->get_cache('google_plus-'.$keyword)){
    $searchResponse = json_decode($searchResponse_decoded);
  } else {
    require_once ('google/contrib/Google_PlusService.php');
    $plus = new Google_PlusService($this->client);
    $searchResponse = $plus->activities->search($keyword); 
    $this->cache->set_cache('google_plus-'.$keyword, json_encode($searchResponse));
  }  
  $this->result["google_plus"][] = $searchResponse;
}

function twitter_list($twitter_list) {
  if($twitter_list_decoded = $this->cache->get_cache($twitter_list)) {
    $twitter_list_result = json_decode($twitter_list_decoded);
  }
  else { 
    $params = array ("owner_screen_name" => "ahmadaassaf","slug" => $twitter_list, "count" => 15 );
    $twitter_list_result = (array) $this->twitter->lists_statuses($params);
    $this->cache->set_cache($twitter_list, json_encode($twitter_list_result));      
  }
  if ($twitter_list_result) $this->result["twitter"][] = $twitter_list_result;

}

function twitter_search($keyword) {
  if($twitter_search_decoded = $this->cache->get_cache('twitter_search-'.$keyword)){
    $twitter_search = json_decode($twitter_search_decoded);
  } else {
    $params = array ("lang" => "en","include_entities" => true,"q" => urlencode($keyword), "rpp" => 10 );
    $twitter_search = (array) $this->twitter->search_tweets($params);
    $this->cache->set_cache('twitter_search-'.$keyword, json_encode($twitter_search));
  }
  if ($twitter_search) $this->result["twitter"][] =  $twitter_search["statuses"];
}

function slideshare($keyword) {
  if($slideshare_search_decoded = $this->cache->get_cache('slideshare-'.$keyword)){
    $slideshare_search = json_decode($slideshare_search_decoded);
  } else {
    $time_stamp = strtotime("now");
    $hash = sha1("4xQZJ8CF". $time_stamp);
    $slideshare_query = "select * from xml where url='https://slideshare.net/api/2/search_slideshows?q=$keyword&page=1&items_per_page=5&sort=relevance&upload_date=year&fileformat=all&lang=en&file_type=all&api_key=IO7frmfl&hash=" . $hash . "&ts=" . $time_stamp ."'";
    $slideshare_search = utility::getYQLResult($slideshare_query);
    $this->cache->set_cache('slideshare-'.$keyword, json_encode($slideshare_search));
  }
  if (isset($slideshare_search->Slideshows->Slideshow)) 
    $this->result["slideshare"][] =  $slideshare_search->Slideshows;
}

function vimeo($keyword) {
  if($response_decoded = $this->cache->get_cache('vimeo-'.$keyword)){
    $vimeo_array = json_decode($response_decoded);
    $this->result["vimeo"][] =  $vimeo_array;
  } else {
    $vimeo_array = array();
    require_once('vimeo-search.php');
    $vimeo = new phpVimeo($this->vimeo_key, $this->vimeo_secret);
    $response = $vimeo->call('vimeo.videos.search', array('per_page' => 5 , 'query' => $keyword, 'sort' => 'relevant'));
    foreach($response->videos->video as $v){
      $videoinfo = $vimeo->call('vimeo.videos.getInfo', array('video_id' => $v->id));
      $vimeo_array[] = $videoinfo->video[0];
    }
    $this->cache->set_cache('vimeo-'.$keyword, json_encode($vimeo_array));
    $this->result["vimeo"][] =  $vimeo_array;
  }  
}
}
?>