<?php 
	
	require_once('DocumentBuilder/semanticDocumentBuilder.php');
	require_once('Utilities/util.php');
	require_once('Utilities/simpleCache.php');

	$semanticDocumentBuilder = new semanticDocumentBuilder();
	$result =  $semanticDocumentBuilder->build("http://www.economist.com/blogs/graphicdetail/2013/05/what-europeans-think-each-other");

	echo json_encode($result);
	
?>