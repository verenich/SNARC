if (!window.snarc) window.snarc = {};

jQuery.extend(window.snarc,
{
    buildSidebar: function(url)
    {

        if (!window.snarc.CONSTANTS.is_snarc_in_action) { 

            window.snarc.CONSTANTS.is_snarc_in_action = true;
            var side_bar                              = $(window.snarc.DOM.sidebar).appendTo($('body'));

            $(window.snarc.DOM.entityInspector).appendTo($('body'));
            $(window.snarc.DOM.toolbar).appendTo(side_bar);
            $(window.snarc.DOM.shutdownButton).appendTo(side_bar);
            $(window.snarc.DOM.loadingFunctionStatus).appendTo(side_bar);
            $(window.snarc.DOM.laodingSNARCStatus).appendTo(side_bar);
            $(window.snarc.DOM.socialAggregationResult).appendTo(side_bar);
            $(window.snarc.DOM.docummentAnnotationResult).appendTo(side_bar);

            window.snarc.attachControl();
            window.snarc.AJAXCall(url);

        } else window.snarc.FUNCTIONS.hideSNARC();

        return true;
    },

    attachControl: function(){

        $(window.snarc.DOM.hideSNARCButton).on('click',function(){
           window.snarc.FUNCTIONS.hideSNARC();
       });
        $(window.snarc.DOM.closeSNARC).on('click',function(){
            window.snarc.FUNCTIONS.removeSNARC();
        });
        $(window.snarc.DOM.toggleEntitiesVisibility).on('click',function() {
            if ($(this).hasClass(window.snarc.DOM.entitiesVisibleIcon)) {
                $(this).removeClass(window.snarc.DOM.entitiesVisibleIcon).addClass(window.snarc.DOM.entitiesHiddenIcon);
                window.snarc.CONSTANTS.hideEntities = true;
            } else {
                $(this).removeClass(window.snarc.DOM.entitiesHiddenIcon).addClass(window.snarc.DOM.entitiesVisibleIcon);
                window.snarc.CONSTANTS.hideEntities = false;
            }
        });
        $(document).mouseup(function (e)
        {
            var container = $(window.snarc.DOM.entityPopup);
            if (container.has(e.target).length === 0) container.hide();
        });
    },

    attachEntities: function() {
        var entities = window.snarc.VIEWS.entityView;
        $.get(chrome.extension.getURL('js/templates/entity-view.tpl'), function(template) {
            $(template).appendTo($('body'));
            $(entities).each(function(i,v) {
                var entity = this.entity;
                $(this.text).each(function(i,v) {
                    $('body:not(.snarc-sidebar)').highlight(v, entity);
                });
            });
            window.snarc.VIEWS.entityView = entities;
            window.snarc.buildEntityInspector();
        });
    },

    buildEntityInspector: function(){

        var entityModel = Backbone.Model.extend({
            defaults: window.snarc.VIEWS.entityView[0],
            initialize  : function() {
                _.bindAll(this,"update");
                this.bind('change', this.update);                 
            },
            update: function() { 
            }
        });

        //initialize a backbone model based on the defined settings
        var entityModel = new entityModel();
        //initialize a backbone view and bind it to the model
        var entityView = Backbone.View.extend({
            initialize: function() {
                entityModel.on('change',this.render,this);
            },
            el: $(window.snarc.DOM.entityPopup),
            render: function(){
              var html = $(window.snarc.DOM.entityPopupTemplate).tmpl(entityModel.toJSON());
              $(this.el).html(html); 
          }
      });
        //create the view variable and render it
        var SNARC_EntityView = new entityView();
        SNARC_EntityView.render();
        //attach the funtion when clicking on an entity on the page
        $(window.snarc.DOM.highlightedEntity).on('mouseover',function(e) {
           var popupCoordinates = $(this).offset();
           var popUp            = $(window.snarc.DOM.entityPopup);
           var highlightValue   = $(this).attr("data-entity");
           var newModel         = _.find(window.snarc.VIEWS.entityView, function(v, k){ if (v.entity === highlightValue) return v; });
           entityModel.set( newModel );
           if (!window.snarc.CONSTANTS.hideEntities) $(window.snarc.DOM.entityPopup).show(); 
           else $(window.snarc.DOM.entityPopup).css('display','none');
           $(window.snarc.DOM.entityPopup).css({'left' : popupCoordinates.left - (popUp.width() / 2 ), 'top' : popupCoordinates.top - popUp.height()})
       });

    },

    AJAXCall: function(url)
    {
        jQuery.ajax(
        {
            url: window.snarc.URLS.SNARC_service_url,
            type: 'POST',
            dataType: 'json',
            data: { url: url },
            success: function(data, textStatus, xhr)
            {
                window.snarc.VIEWS.entityView = data.entities;
                window.snarc.attachEntities();
                $.get(chrome.extension.getURL('js/templates/document-annotations.tpl'), function(template) {

                    $.tmpl(template, data).appendTo(window.snarc.DOM.documentAnnotationScreen);

                    window.snarc.FUNCTIONS.hideSNARCLoader();
                    $(window.snarc.DOM.statusMessage).text(window.snarc.MESSAGES.fetchingSocial);
                    $(window.snarc.DOM.SNARC).niceScroll({cursorcolor:"#000",horizrailenabled: false});

                });
            },
            error: function(xhr, textStatus, errorThrown)
            {
                $(window.snarc.DOM.SNARCLoader).text(window.snarc.MESSAGES.failedAJAXCall).css('color', '#d73532');
                console.log(xhr);
            }
        });
}
});