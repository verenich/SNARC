if (!window.snarc) window.snarc = {};

jQuery.extend(window.snarc,
{
    'DOM': {
        SNARC:'.snarc-sidebar',
        sidebar: '<div class="snarc-sidebar"><span class="snarc-closeHandler"></span></div>',
        toolbar: '<div class="snarc-toolbar"><i class="active_area icon-th-list"></i><i class="toggleEntities icon-eye"</i></div>',
        statusMessage: '.snarc-status',
        shutdownButton: '<span class="shutdown">CLOSE</span>',
        loadingFunctionStatus: '<div class="snarc_message_bar"><div class="snarc-status">Annotating Document ...</div><img class="spinner" src="' + chrome.extension.getURL('icons/social-loader.gif') + '"/></div>',
        laodingSNARCStatus: '<div class="loading"><i class="icon-signal"></i>Loading Social Sidebar<img src="' + chrome.extension.getURL('icons/ajax-loader.gif') + '"/></div>',
        SNARCLoader: '.snarc-sidebar .loading',
        socialAggregationResult: '<ul id = "realted_social" class="social_stream"></ul>',
        docummentAnnotationResult: '<ul id = "document_annotations" class="social_stream"></ul>',
        hideSNARCButton: '.snarc-closeHandler',
        closeSNARC: '.shutdown',
        documentAnnotationScreen: '#document_annotations',
        entityInspector: '<div class="snarc-entity-view"></div>',
        highlightedEntity: '.SNARCHighlight',
        entityPopup : '.snarc-entity-view',
        entityPopupTemplate: "#snarc_entity_view_template",
        toggleEntitiesVisibility: ".toggleEntities",
        entitiesVisibleIcon: "icon-eye",
        entitiesHiddenIcon: "icon-eye-off"
    },
    'CONSTANTS': {
        is_snarc_in_action: false,
        hideEntities:false,
        hide : 'hideSNARC'
    },
    'FUNCTIONS' : {
        hideSNARCLoader: function() { $('.snarc-sidebar .loading').hide(); },
        hideSNARC      : function() { $('.snarc-sidebar').toggleClass(window.snarc.CONSTANTS.hide); },
        removeSNARC    : function() { $('.snarc-sidebar').fadeOut('slow',function(){
                $(this).remove();
                window.snarc.CONSTANTS.is_snarc_in_action = false;
            });
        }
    },
    'ACTIONS' : {
        initialize : "buildSidebar"
    },
    "VIEWS" : {
        entityView : {}
    },
    'URLS': {
        SNARC_service_url: 'http://ahmadassaf.com/SNARC/SNARC-AJAX.php'
    },
    'MESSAGES': {
        failedAJAXCall: 'Error Loading Social Bar .. Please Try to Refresh !',
        fetchingSocial: 'Fetching Related Social News ... '
    }
});