console.log("====== STARTED LISTENING TO COMMUNICATIONS ====== ")

if (!window.snarc) window.snarc = {};

window.snarc.communication =  {};

chrome.runtime.onConnect.addListener(function(port) {
	port.onMessage.addListener(function(msg) {
		port.postMessage({message: msg.message + " -> Received Successfull"});
		if (msg.message === "buildSidebar")
			window.snarc.buildSidebar(msg.url);
	});
});



