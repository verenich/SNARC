console.log("====== SNARC is in action !!! =======");

if (!window.snarc) window.snarc = {};

var is_snarc_in_action = false;

jQuery.extend(window.snarc,
{
    buildSidebar: function(url)
    {
        console.log(" --> Building SNARC Sidebar .... ");
        if (!is_snarc_in_action) { 
            is_snarc_in_action       = true;
            var side_bar             = $('<article class="snarc-sidebar"><span class="snarc-closeHandler"></span></article>').appendTo($('body'));
            var toolbar              = $('<article class="snarc-toolbar"><i class="active_area icon-th-list"></i></article>').appendTo(side_bar);
            var shutdown             = $('<span class="shutdown">CLOSE</span>').appendTo(side_bar);
            var status               = $('<div class="snarc_message_bar"><article class="snarc-status">Annotating Document ...</article><img class="spinner" src="' + chrome.extension.getURL('icons/social-loader.gif') + '"/></div>').appendTo(side_bar);
            var loading_spinner      = '<div class="loading"><i class="icon-signal"></i>Loading Social Sidebar<img src="' + chrome.extension.getURL('icons/ajax-loader.gif') + '"/></div>';
            var social_list          = $('<ul id = "realted_social" class="social_stream"></ul>').appendTo(side_bar);
            var document_annotations = $('<ul id = "document_annotations" class="social_stream"></ul>').appendTo(side_bar);

            $(loading_spinner).appendTo(side_bar);

            window.snarc.AJAXCall(url);
            window.snarc.attachControl();
        } else $('.snarc-sidebar').toggleClass('hideSnarc');

        return true;
    },

    attachControl: function(){
        $('.snarc-closeHandler').on('click',function(){
            $('.snarc-sidebar').toggleClass('hideSnarc');
        });
        $('.shutdown').on('click',function(){
            $('.snarc-sidebar').fadeOut('slow',function(){
                $(this).remove();
                is_snarc_in_action = false;
            });
        });
    },

    AJAXCall: function(url)
    {
        jQuery.ajax(
        {
            url: 'http://ahmadassaf.com/SNARC/SNARC-AJAX.php',
            type: 'POST',
            dataType: 'json',
            data: { url: url },
            success: function(data, textStatus, xhr)
            {
                console.log(data);
                // Asynchronously load the template definition file.
                $.get(chrome.extension.getURL('js/templates/document-annotations.tpl'), function(template)
                {
                 $.tmpl(template, data).appendTo('#document_annotations');
                 $('.snarc-sidebar .loading').hide();
                 $('.snarc-status').text('Fetching Related Social News ... ');
                 $(".snarc-sidebar").niceScroll({cursorcolor:"#000",horizrailenabled: false});
             });
            },
            error: function(xhr, textStatus, errorThrown)
            {
                console.log(xhr);
                $('.snarc-sidebar .loading').text('Error Loading Social Bar').css('color', '#d73532');
            }
        });
}
});